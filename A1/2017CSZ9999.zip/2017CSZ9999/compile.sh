cd starter_code
make clean
make all

