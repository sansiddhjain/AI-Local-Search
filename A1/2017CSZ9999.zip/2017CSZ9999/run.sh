#!/bin/sh
./starter_code/main $1 $2   

